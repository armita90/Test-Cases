package com.example.kotlinmvvmdemo.roomdb

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.kotlinmvvmdemo.dbmodel.*

@Database(entities = arrayOf(
    ProductList::class,
    StorageLocation::class,
    ProductTypeDBModel::class,
    Product::class
    ), version = 1, exportSchema = false)

abstract class DatabaseTable : RoomDatabase() {
    //abstract val storageLocationDatabaseDao: DatabaseDao
    abstract fun DatabaseDao(): DatabaseDao

    companion object {
        @Volatile
        private var INSTANCE: DatabaseTable? = null

        fun getInstance(context: Context): DatabaseTable {
            synchronized(this) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                        context.applicationContext,
                        DatabaseTable::class.java,
                        "databaseName"
                    )
                       .build()
                }
                return INSTANCE as DatabaseTable
            }
        }
    }
}