package com.example.kotlinmvvmdemo.api


import com.example.kotlinmvvmdemo.model.*
import retrofit2.Response
import retrofit2.http.*

interface Api {

    @POST("/v1/user/login")
    suspend fun userLogin(@Body loginPostData: LoginRequest):
            Response<LoginResponse>

    @POST("/v1/storagelocation")
    suspend fun createStorageLocation(@Body createStorageLocation: CreateStorageLocationRequest): Response<CreateStorageLocationResponse>

//    @HTTP(method = "DELETE", path = "/v1/storagelocation", hasBody = true)
//    suspend fun deleteStorageLocations(@Body deleteStorageLocationRequest: DeleteStorageLocationRequest): Response<ServerResponse>
//
//    @PUT("/v1/storagelocation") //updating
//    suspend fun updateStorageLocation(@Body updateStorageLocation: UpdateStorageLocationRequest): Response<CreateStorageLocationResponse>
//
//    @GET("/v1/storagelocation/{userId}")
//    suspend fun getStorageLocation(@Path("userId") userId: String): Response<GetStorageLocationResponse>
//
//    @POST("/v1/images")
//    suspend fun uploadImage(@Body imageUploadRequest: ImageUploadRequest): Response<ImageUploadResponse>

    //@GET("/v1/auditing/fetchAuditLogsforUser/{userId}/{dashboard}")
    // suspend fun getAuditData(@Path("userId")userId: String,
    // @Path("dashboard")dashboard: String): Response<AuditDataResponse>
//}
}