package com.example.kotlinmvvmdemo.model


import com.google.gson.annotations.SerializedName

data class CreateStorageLocationResponse(
   // @SerializedName("data")
    //val `data`: Data,
    @SerializedName("message")
    val message: String,
    @SerializedName("status")
    val status: Int
)