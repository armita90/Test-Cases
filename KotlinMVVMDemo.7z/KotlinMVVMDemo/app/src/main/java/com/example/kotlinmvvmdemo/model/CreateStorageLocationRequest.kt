package com.example.kotlinmvvmdemo.model


import com.google.gson.annotations.SerializedName

data class CreateStorageLocationRequest(
    @SerializedName("status")
    val status: Int, //countUpdated
    @SerializedName("storagelocationData")
    val storagelocationData: List<StoragelocationData>,
    @SerializedName("userId")
    val userId: String?
)