package com.example.kotlinmvvmdemo.api

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiFactory {

    private fun retrofit(): Retrofit = Retrofit.Builder()
        .baseUrl("https://dummyAPi.com")
        .addConverterFactory(GsonConverterFactory.create())
        .build()


    val api: Api = retrofit().create(Api::class.java)

}
