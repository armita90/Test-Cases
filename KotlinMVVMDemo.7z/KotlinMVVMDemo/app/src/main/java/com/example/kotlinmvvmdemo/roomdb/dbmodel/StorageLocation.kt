package com.example.kotlinmvvmdemo.dbmodel

import android.os.Build
import android.os.Parcel
import android.os.Parcelable
import androidx.annotation.RequiresApi
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "storage_location_table")
data class StorageLocation(

    @PrimaryKey()
    @ColumnInfo(name = "storageId")
    var storageId: String,

    @ColumnInfo(name = "userId")
    var userId: String?,

    //flag

    @ColumnInfo(name = "storageName")
    var storageLocationName: String?,

    @ColumnInfo(name = "createdDate")
    var createdDate: String?,

    @ColumnInfo(name = "strorageType")
    var strorageType: String?,

    @ColumnInfo(name = "syncStatus")
    var syncStatus: String?,

    @ColumnInfo(name = "locationCount")
    var locationCount: Int

) : Parcelable {
    @RequiresApi(Build.VERSION_CODES.Q)
    constructor(parcel: Parcel) : this(
        parcel.readString().toString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readInt()
    )

    @RequiresApi(Build.VERSION_CODES.Q)
    override fun writeToParcel(parcel: Parcel?, p1: Int) {
        if (parcel != null) {
            parcel.writeString(storageId)
            parcel.writeString(userId)
            parcel.writeString(storageLocationName)
            parcel.writeString(createdDate)
            parcel.writeString(strorageType)
            parcel.writeString(syncStatus)
            parcel.writeInt(locationCount)
        }
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<StorageLocation> {
        @RequiresApi(Build.VERSION_CODES.Q)
        override fun createFromParcel(parcel: Parcel): StorageLocation {
            return StorageLocation(parcel)
        }

        override fun newArray(size: Int): Array<StorageLocation?> {
            return arrayOfNulls(size)
        }
    }
}
