package com.example.kotlinmvvmdemo.api.apicallrepository


import com.example.kotlinmvvmdemo.api.Api
import com.example.kotlinmvvmdemo.api.RetrofitClient
import com.example.kotlinmvvmdemo.model.CreateStorageLocationRequest
import com.example.kotlinmvvmdemo.model.CreateStorageLocationResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Response

object CreateStorageLocationRepository {

    suspend fun createStorageLocation(createStorageLocationRequest: CreateStorageLocationRequest): CreateStorageLocationResponse? {
        val api = RetrofitClient.getClient().create(Api::class.java)
        val createStorageLocationResponseData: CreateStorageLocationResponse?
        return try {
            var response: Response<CreateStorageLocationResponse>? = null
            withContext(Dispatchers.IO) {
                response = api.createStorageLocation(createStorageLocationRequest)
            }
            createStorageLocationResponseData = response?.body()
            createStorageLocationResponseData

        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }


}