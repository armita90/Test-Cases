package com.example.kotlinmvvmdemo.model


import com.google.gson.annotations.SerializedName

data class LoginResponse(
    @SerializedName("accessToken")
    val accessToken: String,
    @SerializedName("deviceDate")
    val deviceDate: String,
    @SerializedName("message")
    val message: String,
    //@SerializedName("productTypes")
    //val productTypes: List<ProductType>,
    @SerializedName("status")
    val status: Int,
    @SerializedName("userAgreement")
    val userAgreement: Boolean,
    @SerializedName("userId")
    val userId: String
)