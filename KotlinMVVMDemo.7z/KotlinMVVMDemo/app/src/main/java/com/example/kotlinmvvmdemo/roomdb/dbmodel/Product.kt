package com.example.kotlinmvvmdemo.dbmodel

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.annotations.SerializedName

@Entity(tableName = "product_table")
data class Product (

    @SerializedName("productId")
    @PrimaryKey
    @ColumnInfo(name = "productId")
    var productId: String,

    @SerializedName("brand")
    @ColumnInfo(name = "brand")
    var brand: String,

    @SerializedName("subBrand")
    @ColumnInfo(name = "subBrand")
    var subBrand: String,

    @SerializedName("upc")
    @ColumnInfo(name = "upc")
    var upc: String,

    @SerializedName("rollLife")
    @ColumnInfo(name = "rollLife")
    var rollLife: String,

    @SerializedName("sheetCount")
    @ColumnInfo(name = "sheetCount")
    var sheetCount: String,

    @SerializedName("RE")
    @ColumnInfo(name = "RE")
    var rE: String,

    @SerializedName("packCount")
    @ColumnInfo(name = "packCount")
    var packCount: Int

)
