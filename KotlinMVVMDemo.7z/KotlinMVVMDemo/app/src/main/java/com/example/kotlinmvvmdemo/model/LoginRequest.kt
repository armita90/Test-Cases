package com.example.kotlinmvvmdemo.model

import com.google.gson.annotations.SerializedName

data class LoginRequest(
    @SerializedName("deviceBrand")
    val deviceBrand: String,
    @SerializedName("deviceDate")
    val deviceDate: String,
    @SerializedName("deviceId")
    val deviceId: String,
    @SerializedName("deviceModel")
    val deviceModel: String,
    @SerializedName("deviceType")
    val deviceType: String,
    @SerializedName("password")
    val password: String,
    @SerializedName("userId")
    val userId: String
)