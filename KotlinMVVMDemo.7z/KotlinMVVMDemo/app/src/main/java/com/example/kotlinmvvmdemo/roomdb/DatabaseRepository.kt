package com.example.kotlinmvvmdemo.roomdb

import android.app.Application
import com.example.kotlinmvvmdemo.dbmodel.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.CoroutineContext

class DatabaseRepository(application: Application) : CoroutineScope {

    override val coroutineContext: CoroutineContext
        get() = Dispatchers.Main

    private var databaseDao: DatabaseDao? = null

    init {
        val db = DatabaseTable.getInstance(application)
        databaseDao = db.DatabaseDao()
    }

    fun getLocationList(userId: String) = databaseDao?.getStorageLocation(userId)

    fun deleteLocationByStorageId(storageId: String) {
        launch { deleteLocationByStorageIdBG(storageId) }
    }

    private suspend fun deleteLocationByStorageIdBG(storageId: String) {
        withContext(Dispatchers.IO) {
            databaseDao?.deleteLocationByStorageId(storageId)
        }
    }

    fun deleteProductByStorageAndProductID(storageId: String, productId: String) {
        launch { deleteProductByStorageAndProductIDBG(storageId, productId) }
    }

    private suspend fun deleteProductByStorageAndProductIDBG(storageId: String, productId: String) {
        withContext(Dispatchers.IO) {
            databaseDao?.deleteProductByStorageAndProductID(storageId, productId)
        }
    }

    fun setLocationList(storageLocation: StorageLocation) {
        launch { setLocationBG(storageLocation) }
    }

    private suspend fun setLocationBG(storageLocation: StorageLocation) {
        withContext(Dispatchers.IO) {
            databaseDao?.insertStorageLocation(storageLocation)
        }
    }

    //addded
    fun insertProductType(productTypeDBModel: ProductTypeDBModel) {
        launch { insertProductTypeBG(productTypeDBModel) }
    }

    private suspend fun insertProductTypeBG(productTypeDBModel: ProductTypeDBModel) {
        withContext(Dispatchers.IO) {
            databaseDao?.insertProductType(productTypeDBModel)
        }
    }

    fun getProductListFromServer() = databaseDao?.getProductListFromServer()

    fun getProductList() = databaseDao?.getProductDetail()

    fun getProductListByStorageID(key: String) =
        databaseDao?.getProductListByStorageID(key)

    fun setProductList(productList: ProductList) {
        launch { setProductBG(productList) }
    }

    private suspend fun setProductBG(productList: ProductList) {
        withContext(Dispatchers.IO) {
            databaseDao?.insertProductDetails(productList)
        }
    }

    fun updateProductListByStorageID(
        storageId: String,
        product_Count: Int,
        product_Name: String,
        count_Updated_Date: String
    ) {
        launch {
            return@launch updateProductListByStorageIDBG(
                storageId,
                product_Count,
                product_Name,
                count_Updated_Date
            )
        }
    }

    fun updateProductStorageIdByStorageID(
        storageId: String,
        storageProductJunctionId: String,
        product_Name: String
    ) {
        launch {
            return@launch updateProductStorageIdIDBG(
                storageId,
                storageProductJunctionId,
                product_Name
            )
        }
    }

    private suspend fun updateProductListByStorageIDBG(
        storageId: String,
        product_Count: Int,
        product_Name: String,
        count_Updated_Date: String
    ) {
        withContext(Dispatchers.IO) {
            return@withContext databaseDao?.updateProductListByStorageID(
                storageId,
                product_Count,
                product_Name,
                count_Updated_Date
            )
        }
    }

    private suspend fun updateProductStorageIdIDBG(
        storageId: String,
        storageProductJunctionId: String,
        product_Name: String
    ) {
        withContext(Dispatchers.IO) {
            return@withContext databaseDao?.updateProductStorageIdByStorageID(
                storageId,
                storageProductJunctionId,
                product_Name
            )
        }
    }

    fun updateStorageSyncStatus( //updateStorageSyncStatus
        syncStatus: String,
        storageId: String,
        userId: String
    ) {
        launch {
            return@launch updateStorageSyncStatusBG(
                syncStatus, storageId, userId
            )
        }
    }

    private suspend fun updateStorageSyncStatusBG(
        syncStatus: String,
        storageId: String,
        userId: String
    ) {
        withContext(Dispatchers.IO) {
            return@withContext databaseDao?.updateStorageSyncStatus(
                syncStatus, storageId, userId
            )
        }
    }

    fun updateStorageLocationById(
        storageId: String,
        storageName: String,
        strorageType: String,
        locationCount: Int,
        syncStatus: String
    ) {
        launch {
            return@launch updateStorageLocationByIdBG(
                storageId,
                storageName,
                strorageType,
                locationCount,
                syncStatus
            )
        }
    }

    private suspend fun updateStorageLocationByIdBG(
        storageId: String,
        storageName: String,
        strorageType: String,
        locationCount: Int,
        syncStatus: String
    ) {
        withContext(Dispatchers.IO) {
            return@withContext databaseDao?.updateStorageLocationById(
                storageId,
                storageName,
                strorageType,
                locationCount,
                syncStatus
            )
        }
    }
    fun getUnSyncStorageLocation() =
        databaseDao?.getUnSyncStorageLocation("false")


    fun setProductData(productsList: List<Product>) {
        launch { setProductsBG(productsList) }
    }

    private suspend fun setProductsBG(productsList: List<Product>) {
        withContext(Dispatchers.IO) {
            databaseDao?.insertAllProducts(productsList)
        }
    }

    fun getProductForUpc(upc: String) = databaseDao?.getProductForUpc(upc)

    fun deleteAllProducts() {
        launch { deleteAllProductsBG() }
    }

    private suspend fun deleteAllProductsBG() {
        withContext(Dispatchers.IO) {
            databaseDao?.deleteAllProducts()
        }
    }

    /*fun getStorageJunctionId(storageid: String, product_Name: String): String {
        var junctionId = null
        launch { junctionId = getProductJunctionIdByStorageIdBG(storageid, product_Name) }
        return junctionId
    }

    private suspend fun getProductJunctionIdByStorageIdBG(storageid: String, product_Name: String): String {
        var junctionId = null
        withContext(Dispatchers.IO) {
            junctionId = databaseDao!!.getProductJunctionIdByStorageID(storageid, product_Name)
        }
        return junctionId
    }*/

    fun getProductJunctionIdByStorageId(storageid: String, product_Name: String) =
        databaseDao!!.getProductJunctionIdByStorageID(storageid, product_Name)


}