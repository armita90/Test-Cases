package com.example.kotlinmvvmdemo.model


import com.google.gson.annotations.SerializedName

data class ProductTypeStorageLocation(
    @SerializedName("count")
    var count: Int,
    @SerializedName("name")
    val name: String?,
    @SerializedName("productTypeId")
    val productTypeId: String?,
    @SerializedName("storageProductJunctionId")
    val storageProductJunctionId: String?,
    @SerializedName("updatedDate")
    val updatedDate: String?
)