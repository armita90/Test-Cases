package com.example.kotlinmvvmdemo.dbmodel

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "product_type_table")
data class ProductTypeDBModel(

    @PrimaryKey(autoGenerate = true)
    var Id: Long = 0L,

    @ColumnInfo(name = "productTypeId")
    var productTypeId: String ,

    @ColumnInfo(name = "productTypeName")
    var productTypeName: String

    )