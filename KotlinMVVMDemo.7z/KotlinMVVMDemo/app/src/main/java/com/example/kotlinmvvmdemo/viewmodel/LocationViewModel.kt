package com.example.kotlinmvvmdemo.viewmodel

import android.app.Application
import android.content.SharedPreferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.kotlinmvvmdemo.api.apicallrepository.CreateStorageLocationRepository
import com.example.kotlinmvvmdemo.dbmodel.ProductList
import com.example.kotlinmvvmdemo.dbmodel.ProductTypeDBModel
import com.example.kotlinmvvmdemo.dbmodel.StorageLocation
import com.example.kotlinmvvmdemo.model.CreateStorageLocationRequest
import com.example.kotlinmvvmdemo.model.CreateStorageLocationResponse
import com.example.kotlinmvvmdemo.roomdb.DatabaseRepository

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class LocationViewModel(application: Application) : AndroidViewModel(application) {

    var locationLiveData: LiveData<List<StorageLocation>>? = null

    var productLiveData: LiveData<List<ProductList>>? = null
    var productTypeDBModel: LiveData<List<ProductTypeDBModel>>? = null
    var junctionLiveData : LiveData<String>? = null
    var mRepository: DatabaseRepository? = null
    private var PRIVATE_MODE = 0
    private val PREF_NAME = "user_id"
    var userID: String? = null

    init {
        mRepository = DatabaseRepository(application)
        productLiveData = mRepository?.getProductList()
        productTypeDBModel = mRepository?.getProductListFromServer()
        val sharedPref: SharedPreferences =
            application.getSharedPreferences(PREF_NAME, PRIVATE_MODE)
        userID = sharedPref.getString(PREF_NAME, " ")
        locationLiveData = userID?.let { mRepository?.getLocationList(it) }
    }

    //change method name
    internal fun getAllStorageLocationListFromDB(): LiveData<List<StorageLocation>>? {
        return locationLiveData
    }

    fun deleteLocationByStorageId(storageId: String) {
        mRepository?.deleteLocationByStorageId(storageId)
    }

    fun deleteProductByStorageAndProductID(storageId: String, productId: String) {
        mRepository?.deleteProductByStorageAndProductID(storageId, productId)
    }

    fun insertLocation(storageLocation: StorageLocation) {
        mRepository?.setLocationList(storageLocation)
    }

    internal fun getAllProductList(): LiveData<List<ProductList>>? {
        return productLiveData
    }

    internal fun getServerProductListFromDB(): LiveData<List<ProductTypeDBModel>>? {
        return productTypeDBModel
    }

    internal fun getProductListByStorageID(storageId: String): LiveData<List<ProductList>>? {
        return mRepository?.getProductListByStorageID(storageId)
    }

    fun updateProductListByStorageID(
        storageId: String,
        product_Count: Int,
        product_Name: String, count_Updated_Date: String
    ): Unit? {
        return mRepository?.updateProductListByStorageID(
            storageId,
            product_Count,
            product_Name, count_Updated_Date
        )
    }

    fun updateProductJunctionIdByStorageID(
        storageId: String,
        storageProductJunctionId: String,
        product_Name: String
    ): Unit? {
        return mRepository?.updateProductStorageIdByStorageID(
            storageId,
            storageProductJunctionId,
            product_Name
        )
    }

    fun updateStorageLocationById(
        storageId: String,
        storageName: String,
        strorageType: String,
        locationCount: Int,
        syncStatus: String
    ): Unit? {
        return mRepository?.updateStorageLocationById(
            storageId,
            storageName,
            strorageType,
            locationCount,
            syncStatus
        )
    }

    fun updateStorageSyncStatus(
        syncStatus: String, storageId: String, userId: String
    ): Unit? {
        return mRepository?.updateStorageSyncStatus(
            syncStatus, storageId, userId
        )
    }

    fun insertProduct(productList: ProductList) {
        mRepository?.setProductList(productList)
    }



    fun getProductJunctionIdByStorageId(storageid: String, product_Name: String): LiveData<String>{
        return mRepository!!.getProductJunctionIdByStorageId(storageid, product_Name)
    }

    //CreateStorageLocationViewModel
    private val viewModelJob = Job()
    private val coroutineScope = CoroutineScope(viewModelJob + Dispatchers.Main)
    var createStorageLocationResponseLiveData: MutableLiveData<CreateStorageLocationResponse>? =
        MutableLiveData()
    //var serverResponseLiveData: MutableLiveData<ServerResponse>? = MutableLiveData()

    fun setStorageLocationDataToServer(createStorageLocationRequest: CreateStorageLocationRequest): MutableLiveData<CreateStorageLocationResponse>? {

        coroutineScope.launch {
            createStorageLocationResponseLiveData?.value =
                CreateStorageLocationRepository.createStorageLocation(createStorageLocationRequest)
        }
        return createStorageLocationResponseLiveData
    }

//    fun updateStorageLocationResponse(updateStorageLocationRequest: UpdateStorageLocationRequest): MutableLiveData<CreateStorageLocationResponse>? {
//
//        coroutineScope.launch {
//            createStorageLocationResponseLiveData?.value =
//                UpdateStorageLocationRepository.updateStorageLocation(updateStorageLocationRequest)
//        }
//        return createStorageLocationResponseLiveData
//    }
//
//    fun deleteStorageLocation(deleteStorageLocationRequest: DeleteStorageLocationRequest): MutableLiveData<ServerResponse>? {
//        coroutineScope.launch {
//            serverResponseLiveData?.value =
//                DeleteStorageLocationRepository.deleteStorageLocation(deleteStorageLocationRequest)
//        }
//        return serverResponseLiveData
//    }
}

