package com.example.kotlinmvvmdemo.dbmodel

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "product_list_table")
data class ProductList (

    @PrimaryKey(autoGenerate = true)
    var Id: Long = 0L,

    @ColumnInfo(name = "productId")
    var productId: String = "0",

    @ColumnInfo(name = "productName")
    var productName: String,

    @ColumnInfo(name = "productCount")
    var productCount: Int,

    @ColumnInfo(name = "storageId")
    var storageID: String,

    @ColumnInfo(name = "productAddedDate")
    var productAddedDate: String,

    @ColumnInfo(name = "storageProductJunctionId")
    var storageProductJunctionId: String
)
