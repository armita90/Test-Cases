package com.example.kotlinmvvmdemo.api



interface TrackingApi {
    //@GET("/v1/auditing/fetchAuditLogsforUser/{userId}/{dashboard}")
   // suspend fun getAuditData(@Path("userId")userId: String,
    // @Path("dashboard")dashboard: String): Response<AuditDataResponse>
}