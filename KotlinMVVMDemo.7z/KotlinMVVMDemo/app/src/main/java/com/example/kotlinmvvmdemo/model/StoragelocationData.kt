package com.example.kotlinmvvmdemo.model


import com.google.gson.annotations.SerializedName

data class StoragelocationData(
    @SerializedName("locationCount")
    val locationCount: Int,

    @SerializedName("productType")
    val productType: List<ProductTypeStorageLocation>,
    @SerializedName("storageId")
    val storageId: String?,
    @SerializedName("storageName")
    val storageName: String?,
    @SerializedName("storageType")
    val storageType: String?,
    @SerializedName("updatedAt")
    val updatedAt: String?
)