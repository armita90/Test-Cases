package com.example.kotlinmvvmdemo.view.location

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.content.res.Resources
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import java.text.SimpleDateFormat
import java.util.*
import androidx.lifecycle.Observer
import com.example.kotlinmvvmdemo.R
import com.example.kotlinmvvmdemo.dbmodel.ProductList
import com.example.kotlinmvvmdemo.dbmodel.StorageLocation
import com.example.kotlinmvvmdemo.model.ProductTypeStorageLocation
import com.example.kotlinmvvmdemo.viewmodel.LocationViewModel
import kotlin.collections.ArrayList

class AddNewLocation : AppCompatActivity() {

    var mViewModel: LocationViewModel? = null
    var storageLocationValue: StorageLocation? = null
    var storageTypeTextView: TextView? = null
    var listOfProduct: List<ProductList>? = null
    var addedProductList: ArrayList<ProductTypeStorageLocation>? = null
    var isBathTissueWasSelected: Boolean = false
    var isPaperTowelWasSelected: Boolean = false
    var productIdBathTissue: String? = null
    var productIdPaperTowel: String? = null
    private var PRIVATE_MODE = 0
    private val PREF_NAME = "user_id"
    var userID: String? = null
    //
//    var storageName: String? = null
//    var strType: String? = null
//    var createdDate: String? = null
//    var storageId: String? = null
//    var locationCount: Int = 0
    lateinit var storageNameEdtTxt: EditText
    lateinit var locationCountEdtTxt: EditText
    var hashmap: HashMap<String, ProductList>? = HashMap<String, ProductList>()
    var storageLocation: StorageLocation? = null


    @SuppressLint("SimpleDateFormat")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.add_new_location)
        mViewModel = ViewModelProvider(this).get(LocationViewModel::class.java)
        addedProductList = ArrayList()

        strName.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                if (strName.text.isNotEmpty() && location_count.text.isNotEmpty()) {
                    confirm.setBackgroundResource(R.drawable.ic_button_bg_enabled_l)
                    confirm.isClickable = true
                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }
        })

        location_count.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                if (strName.text.isNotEmpty() && location_count.text.isNotEmpty()) {
                    confirm.setBackgroundResource(R.drawable.ic_button_bg_enabled_l)
                    confirm.isClickable = true
                }
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }
        })

        val adapter = ArrayAdapter.createFromResource(
            this, R.array.locations_list,
            android.R.layout.simple_spinner_dropdown_item
        )
        val res: Resources = resources
        val locationsListArray = res.getStringArray(R.array.locations_list)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        storrageType.adapter = adapter

        //cacll
        getProductDetail()

        if (storageLocationValue != null)
            storrageType.setSelection(locationsListArray.indexOf(storageLocationValue!!.strorageType))
        storrageType?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                storrageType.setSelection(position)
                storageTypeTextView = view as TextView
                storageTypeTextView!!.setTextColor(Color.BLACK)
            }
        }
        bath_tissues_unselected.setOnClickListener {
            bath_tissues_unselected.isChecked = !bath_tissues_unselected.isChecked
            if (bath_tissues_unselected.isChecked) {
                iv_bath_tissue_tick.visibility = View.VISIBLE

            } else {
                iv_bath_tissue_tick.visibility = View.INVISIBLE
            }
        }
        paper_towels_unselected.setOnClickListener {
            paper_towels_unselected.isChecked = !paper_towels_unselected.isChecked
            if (paper_towels_unselected.isChecked) {
                iv_paper_towel_tick.visibility = View.VISIBLE
            } else {
                iv_paper_towel_tick.visibility = View.INVISIBLE
            }
        }

        confirm.setOnClickListener {
            if (CommonMethod.isNetworkAvailable(this)) {
                if (strName.text.isNotEmpty() && location_count.text.isNotEmpty() && paper_towels_unselected.isChecked || bath_tissues_unselected.isChecked) {
                    val sharedPref: SharedPreferences =
                        getSharedPreferences(PREF_NAME, PRIVATE_MODE)
                    userID = sharedPref.getString(PREF_NAME, " ")

                    if (strName != null && location_count != null && storrageType != null) {
                        val storageName = strName.text.toString()
                        val locationCount = location_count.text.toString().toInt()
                        val strType = storrageType.selectedItem.toString()

                        val timeStamp: String =
                            SimpleDateFormat("ddMMyyyyHHmmss.SSSSS").format(Date())
                        val storageId = userID + timeStamp
                        val createdDate = SimpleDateFormat("dd MMM yyyy").format(Date())

                        storageLocation = StorageLocation(
                            storageId = storageId!!,
                            userId = userID!!,
                            storageLocationName = storageName,
                            createdDate = "Created on $createdDate",
                            strorageType = strType,
                            syncStatus = "true", //false
                            locationCount = locationCount
                        )

                        val paperTowel = ProductList(
                            productId = productIdPaperTowel!!,
                            productName = paper_towels_unselected.text.toString(),
                            productCount = 0,
                            storageID = storageId!!,
                            productAddedDate = createdDate!!,
                            storageProductJunctionId = ""
                        )
                        val bathTissue = ProductList(
                            productId = productIdBathTissue!!,
                            productName = bath_tissues_unselected.text.toString(),
                            productCount = 0,
                            storageID = storageId!!,
                            productAddedDate = createdDate!!,
                            storageProductJunctionId = ""
                        )


                        if (storageLocationValue == null) { // insert
                            //insert data to db
                            mViewModel!!.insertLocation(storageLocation!!)
                            if (paper_towels_unselected.isChecked) {
                                mViewModel!!.insertProduct(paperTowel)
                                val product = ProductTypeStorageLocation(
                                    count = 0,
                                    name = paperTowel.productName,
                                    productTypeId = paperTowel.productId,
                                    storageProductJunctionId = paperTowel.storageProductJunctionId,
                                    updatedDate = createdDate
                                )
                                addedProductList!!.add(product)
                            }

                            if (bath_tissues_unselected.isChecked) {
                                mViewModel!!.insertProduct(bathTissue)
                                val product = ProductTypeStorageLocation(
                                    count = 0,
                                    name = bathTissue.productName,
                                    productTypeId = bathTissue.productId,
                                    storageProductJunctionId = bathTissue.storageProductJunctionId,
                                    updatedDate = createdDate
                                )
                                addedProductList!!.add(product)
                            }

                            //insert data to API
                            //API call //nw chk
                            //on success changing sync status to true in db
                            if (CommonMethod.isNetworkAvailable(this)) {
                                //progess bar
                                add_new_location_progressbar.visibility = View.VISIBLE
                                mViewModel!!.setStorageLocationDataToServer(
                                    getCreateStorageLocationRequest()
                                )
                                    ?.observe(this, Observer { createStorageLocationResponse ->
                                        if (createStorageLocationResponse != null) {
                                            //on success changing sync status to true in db
                                            if (createStorageLocationResponse.status == 200) {
//                                                mViewModel!!.updateStorageSyncStatus(
//                                                    "true",
//                                                    storageId!!,
//                                                    userID!!
//                                                )
                                                var productList =
                                                    createStorageLocationResponse.data.storagelocationData.get(
                                                        0
                                                    ).productType
                                                productList.forEach {
                                                    mViewModel!!.updateProductJunctionIdByStorageID(
                                                        createStorageLocationResponse.data.storagelocationData.get(0).storageId,
                                                        it.storageProductJunctionId!!,
                                                        it.name!!
                                                    )
                                                }


                                            }
                                        }
                                        add_new_location_progressbar.visibility = View.INVISIBLE
                                        finish()
                                    })
                            } else {
                                add_new_location_progressbar.visibility = View.INVISIBLE
                                finish()
                            }

                        } else {//update
                            //Update data to db, with syncStatus false
                            //updating storage location value
                            //get all the proc

                            storageLocation!!.storageLocationName?.let { it1 ->
                                storageLocation!!.strorageType?.let { it2 ->
                                    mViewModel!!.updateStorageLocationById(
                                        storageLocationValue!!.storageId,
                                        it1, it2,
                                        storageLocation!!.locationCount, "true" //false
                                    )
                                }
                            }
                            //updating product detail

                            if (paper_towels_unselected.isChecked && !isPaperTowelWasSelected) {
                                var product: ProductList? =
                                    hashmap?.get(paper_towels_unselected.text.toString())
                                var storageProductJunctionId: String = " "
                                if (product != null) {
                                    storageProductJunctionId = product.storageProductJunctionId
                                }
                                val paperTowelProduct = ProductList(
                                    productId = productIdPaperTowel!!,
                                    productName = paper_towels_unselected.text.toString(),
                                    productCount = 0,
                                    storageID = storageLocationValue!!.storageId,
                                    productAddedDate = createdDate!!,
                                    storageProductJunctionId = storageProductJunctionId
                                )
                                mViewModel!!.insertProduct(paperTowelProduct)

                                val productTypeStorageLocation = ProductTypeStorageLocation(
                                    count = 0,
                                    name = paperTowelProduct.productName,
                                    productTypeId = paperTowelProduct.productId,
                                    storageProductJunctionId = paperTowelProduct.storageProductJunctionId,
                                    updatedDate = createdDate
                                )
                                addedProductList!!.add(productTypeStorageLocation)

                            }
                            if (isPaperTowelWasSelected && !paper_towels_unselected.isChecked) {
                                mViewModel!!.deleteProductByStorageAndProductID(
                                    storageLocationValue!!.storageId,
                                    productIdPaperTowel!! //todo chk delete
                                )
                                for (i in addedProductList!!.indices) {
                                    if (addedProductList!![i].name!!.equals(paper_towels_unselected.text)) {
                                        addedProductList!!.removeAt(i)
                                        break
                                    }

                                }
                            }

                            if (bath_tissues_unselected.isChecked && !isBathTissueWasSelected) {

                                var product: ProductList? =
                                    hashmap?.get(paper_towels_unselected.text.toString())
                                var storageProductJunctionId: String = " "
                                if (product != null) {
                                    storageProductJunctionId = product.storageProductJunctionId
                                }
                                val bathTissueProduct = ProductList(
                                    productId = productIdBathTissue!!,
                                    productName = bath_tissues_unselected.text.toString(),
                                    productCount = 0,
                                    storageID = storageLocationValue!!.storageId,
                                    productAddedDate = createdDate!!,
                                    storageProductJunctionId = storageProductJunctionId
                                )
                                    mViewModel!!.insertProduct(bathTissueProduct)

                                    val productTypeStorageLocation = ProductTypeStorageLocation(
                                        count = 0,
                                        name = bathTissueProduct.productName,
                                        productTypeId = bathTissueProduct.productId,
                                        storageProductJunctionId = bathTissueProduct.storageProductJunctionId,
                                        updatedDate = createdDate
                                    )
                                    addedProductList!!.add(productTypeStorageLocation)
                                }


                            if (isBathTissueWasSelected && !bath_tissues_unselected.isChecked) {
                                mViewModel!!.deleteProductByStorageAndProductID(
                                    storageLocationValue!!.storageId,
                                    productIdBathTissue!!
                                )
                                for (i in addedProductList!!.indices) {
                                    if (addedProductList!![i].name!!.equals(bath_tissues_unselected.text)) {
                                        addedProductList!!.removeAt(i)
                                        break
                                    }
                                }
                            }
                            //update data to db done
                            //now updating data to api
                            //API call str1 - sync fals
                            if (CommonMethod.isNetworkAvailable(this)) {
                                add_new_location_progressbar.visibility = View.VISIBLE
                                mViewModel!!.updateStorageLocationResponse(
                                    updateStorageLocationToServer()
                                )
                                    ?.observe(this, Observer { createStorageLocationResponse ->
                                        if (createStorageLocationResponse != null) {
                                //on success changing sync status to true in db
                                            if (createStorageLocationResponse.status == 200) {
                                                /*mViewModel!!.updateStorageSyncStatus(
                                                    "true",
                                                    storageId!!,
                                                    userID!!
                                                )*/
                                                var productList =
                                                    createStorageLocationResponse.data.storagelocationData.get(
                                                        0
                                                    ).productType
                                                productList.forEach {
                                                    mViewModel!!.updateProductJunctionIdByStorageID(
                                                        createStorageLocationResponse.data.storagelocationData.get(0).storageId,
                                                        it.storageProductJunctionId!!,
                                                        it.name!!
                                                    )
                                                }
                                            }
                                        }
                                        add_new_location_progressbar.visibility = View.INVISIBLE
                                        finish()
                                    })
                            } else {
                                add_new_location_progressbar.visibility = View.INVISIBLE
                                finish()
                            }
                        }

                    }
                } else {
                    CommonMethod.showAlertDialog(this, "Alert!", "Please enter all the fields")
                }
            } else {
                CommonMethod.showAlertDialog(
                    this,
                    "Alert!",
                    "Please check you internet connection."
                )

            }
        }
        cancel_action.setOnClickListener {
            finish()
        }
    }

    private fun getCreateStorageLocationRequest(): CreateStorageLocationRequest {

        val storagelocationData = StoragelocationData(
            storageLocation!!.locationCount, addedProductList!!,
            storageLocation!!.storageId,
            storageLocation!!.storageLocationName, storageLocation!!.strorageType,
            storageLocation!!.createdDate
        )

        lateinit var storagelocationDataList: ArrayList<StoragelocationData>
        storagelocationDataList = ArrayList()
        storagelocationDataList.add(storagelocationData)

        return CreateStorageLocationRequest(
            0, storagelocationDataList
            , userID
        )
    }

    private fun getProductDetail() {

        mViewModel!!.getServerProductListFromDB()
            ?.observe(this, Observer<List<ProductTypeDBModel>>
            {
                productIdBathTissue = it.get(1).productTypeId
                bath_tissues_unselected.text = it.get(1).productTypeName
                // bath_tissues_unselected.tag = it.get(0).productTypeId

                productIdPaperTowel = it.get(0).productTypeId
                paper_towels_unselected.text = it.get(0).productTypeName
                //paper_towels_unselected.tag= it.get(1).productTypeId

                setStorageValueToFields()

            })

    }

    private fun setStorageValueToFields() {
        val intent = getIntent();
        if (intent.hasExtra("storageLocation")) { // call add new location in update mode
            storageLocationValue = intent.getParcelableExtra("storageLocation")
            strName.setText(storageLocationValue!!.storageLocationName)
            location_count.setText(storageLocationValue!!.locationCount.toString())

            mViewModel!!.getProductListByStorageID(storageLocationValue!!.storageId)
                ?.observe(this, Observer<List<ProductList>>
                {
                    listOfProduct = it
                    for (x in it.indices) {
                        hashmap?.put(it[x].productName, it[x])

                        val productTypeStorageLocation = ProductTypeStorageLocation(
                            count = 0,
                            name = it[x].productName,
                            productTypeId = it[x].productId,
                            storageProductJunctionId = it[x].storageProductJunctionId,
                            updatedDate = it[x].productAddedDate
                        )
                        addedProductList!!.add(productTypeStorageLocation)

                        when (it.get(x).productId) {
                            productIdBathTissue -> {
                                bath_tissues_unselected.isChecked = true
                                isBathTissueWasSelected = true
                                iv_bath_tissue_tick.visibility = View.VISIBLE
                            }
                            productIdPaperTowel -> {
                                isPaperTowelWasSelected = true
                                paper_towels_unselected.isChecked = true
                                iv_paper_towel_tick.visibility = View.VISIBLE
                            }
                            else -> { // Note the block
                                print("x is neither 1 nor 2")
                            }
                        }

                    }
                })
        }


    }

    private fun updateStorageLocationToServer(): UpdateStorageLocationRequest {

        val storagelocationData = StoragelocationData(
            storageLocation!!.locationCount, addedProductList!!,
            storageLocation!!.storageId,
            storageLocation!!.storageLocationName, storageLocation!!.strorageType,
            storageLocation!!.createdDate
        )

        lateinit var storagelocationDataList: ArrayList<StoragelocationData>
        storagelocationDataList = ArrayList()
        storagelocationDataList.add(storagelocationData)

        return UpdateStorageLocationRequest(
            0, storagelocationDataList
            , userID, false
        )
    }
}