package com.example.kotlinmvvmdemo.roomdb

import androidx.lifecycle.LiveData
import androidx.room.*
import com.example.kotlinmvvmdemo.dbmodel.*

@Dao
interface DatabaseDao {
    @Insert
    fun insertStorageLocation(location: StorageLocation)

    @Insert
    fun insertProductType(productType: ProductTypeDBModel)

    @Update
    fun updateStorageLocation(location: StorageLocation)

    @Query(
        "UPDATE storage_location_table SET  storageName = :storageName, " +
                "strorageType = :strorageType, locationCount = :locationCount, syncStatus = :syncStatus" +
                " WHERE storageId = :storageId"
    )
    fun updateStorageLocationById(
        storageId: String,
        storageName: String,
        strorageType: String,
        locationCount: Int,
        syncStatus: String
    )

    @Query(value = "Select * from storage_location_table WHERE userId = :userId")
    fun getStorageLocation(userId: String): LiveData<List<StorageLocation>>

    @Query("DELETE FROM storage_location_table WHERE storageId = :storageId")
    fun deleteLocationByStorageId(storageId: String)

    @Insert
    fun insertProductDetails(productList: ProductList)

    @Update
    fun updateProductCount(productList: ProductList)

    @Query(value = "Select * from product_list_table")
    fun getProductDetail(): LiveData<List<ProductList>>

    @Query("SELECT * from product_list_table WHERE storageId = :key")
    fun getProductListByStorageID(key: String): LiveData<List<ProductList>>

    @Query("SELECT storageProductJunctionId from product_list_table WHERE storageId = :key AND productName = :product_Name")
    fun getProductJunctionIdByStorageID(key: String, product_Name: String): LiveData<String>

    @Query("UPDATE storage_location_table SET  syncStatus = :syncStatus  WHERE storageId = :storageId AND userId = :userId")
    fun updateStorageSyncStatus(
        syncStatus: String,
        storageId: String,
        userId: String
    ): Int

    @Query("UPDATE product_list_table SET  productCount = :product_Count, productAddedDate = :count_Updated_Date WHERE storageId = :storageId AND productName = :product_Name")
    fun updateProductListByStorageID(
        storageId: String,
        product_Count: Int,
        product_Name: String,
        count_Updated_Date: String
    ): Int

    @Query("UPDATE product_list_table SET  storageProductJunctionId = :storageProductJunctionId WHERE storageId = :storageId AND productName = :product_Name")
    fun updateProductStorageIdByStorageID(
        storageId: String,
        storageProductJunctionId: String,
        product_Name: String
    ): Int



    @Query("DELETE FROM product_list_table WHERE storageId = :storageId and productId = :productId")
    fun deleteProductByStorageAndProductID(storageId: String, productId: String)

    @Query(value = "Select * from product_type_table")
    fun getProductListFromServer(): LiveData<List<ProductTypeDBModel>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAllProducts(entity: List<Product>)

    @Query(value = "Select * from product_table WHERE upc = :upc")
    fun getProductForUpc(upc: String): LiveData<Product>

    @Query("DELETE FROM product_table")
    fun deleteAllProducts()

    //get all unsync storage location from db
    @Query(value = "Select * from storage_location_table WHERE syncStatus = :syncStatus")
    fun getUnSyncStorageLocation(syncStatus: String): LiveData<List<StorageLocation>>?

    @Query("SELECT * from product_list_table WHERE storageId = :key")
    fun getUnSyncProductListByStorageID(key: String): List<ProductList>

}
